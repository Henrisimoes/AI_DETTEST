from docxtpl import DocxTemplate
from datetime import datetime
from gerar_ia import gerar_texto_ia
import locale
import os
import re

# Configura locale para português brasileiro para a data formatada
# Use um locale mais universal para evitar problemas entre sistemas
try:
    locale.setlocale(locale.LC_TIME, 'pt_BR.UTF-8')
except locale.Error:
    try:
        locale.setlocale(locale.LC_TIME, 'pt_BR')
    except locale.Error:
        locale.setlocale(locale.LC_TIME, '') # Fallback para o padrão do sistema

def sanitize_filename(filename):
    """
    Remove ou substitui caracteres inválidos em nomes de arquivo.
    Mantém letras, números, espaços, hífens e underscores.
    Espaços múltiplos são convertidos em um único underscore.
    """
    # Substitui espaços por underscores
    filename = filename.replace(' ', '_')
    # Remove caracteres inválidos que não são permitidos em nomes de arquivo do Windows/Linux
    # (:, /, \, *, ?, ", <, >, |) e outros especiais como ; , ( ) – (en dash)
    filename = re.sub(r'[\\/:*?"<>|,;()–]', '', filename)
    # Substitui múltiplos underscores por um único
    filename = re.sub(r'_+', '_', filename)
    # Remove underscores do início ou fim
    filename = filename.strip('_')
    # Opcional: Limitar o comprimento para evitar problemas de MAX_PATH (Windows)
    if len(filename) > 150:
        filename = filename[:150]
    return filename

def gerar_opcoes_marcadas(opcao_escolhida, opcoes_dict):
    linhas = []
    # Define largura fixa para alinhar "(X)" + label pela maior label
    max_label_len = 0
    if opcoes_dict:
        max_label_len = max(len(label) for label in opcoes_dict)

    for label, chave in opcoes_dict.items(): # Note que 'chave' aqui é o value do dict (o texto completo)
        marcado = "(X)" if chave == opcao_escolhida else "( )" # A comparação deve ser com o texto completo
        # Espaçamento: label alinhada à direita com padding para ficar visualmente organizado
        linha = f"{marcado} {label.ljust(max_label_len)}"
        linhas.append(linha)

    return "\n".join(linhas)


def gerar_dfd_completo(dados_formulario, lista_itens):
    template_path = os.path.join(os.path.dirname(__file__), "templates", "modelo_dfd.docx")
    doc = DocxTemplate(template_path)

    dados_formulario["descricao"] = gerar_texto_ia(dados_formulario, "descricao")
    dados_formulario["justificativa"] = gerar_texto_ia(dados_formulario, "justificativa")
    dados_formulario["objetivo"] = gerar_texto_ia(dados_formulario, "objetivo")
    dados_formulario["planejamento"] = gerar_texto_ia(dados_formulario, "planejamento")
    # A equipe é fixa em "NÃO SE APLICA" no gerar_ia.py, mas o campo pode ser utilizado se necessário
    dados_formulario["equipe"] = gerar_texto_ia(dados_formulario, "equipe") 

    etp_resultado = gerar_texto_ia(dados_formulario, "estudo_tecnico")
    plano_resultado = gerar_texto_ia(dados_formulario, "plano_contratacao")

    if etp_resultado and etp_resultado.strip().upper().startswith("SIM"):
        dados_formulario["estudo_tecnico_marcado"] = "(X) SIM\n( ) NÃO"
        dados_formulario["justificativa_etp"] = ""
    else:
        dados_formulario["estudo_tecnico_marcado"] = "( ) SIM\n(X) NÃO"
        dados_formulario["justificativa_etp"] = etp_resultado

    if plano_resultado and plano_resultado.strip().upper().startswith("SIM"):
        dados_formulario["plano_contratacao_marcado"] = "(X) SIM\n( ) NÃO"
        dados_formulario["justificativa_pca"] = ""
    else:
        dados_formulario["plano_contratacao_marcado"] = "( ) SIM\n(X) NÃO"
        dados_formulario["justificativa_pca"] = plano_resultado

    opcoes_objeto = {
        "Material de consumo": "Material de consumo",
        "Material permanente": "Material permanente",
        "Equipamento de TI": "Equipamento de TI",
        "Serviço não continuado": "Serviço não continuado",
        "Serviço sem dedicação exclusiva de mão de obra": "Serviço sem dedicação exclusiva de mão de obra",
        "Serviço com dedicação exclusiva de mão de obra": "Serviço com dedicação exclusiva de mão de obra"
    }

    opcoes_forma = {
        "Modalidades da Lei nº 14.133/21": "Modalidades da Lei nº 14.133/21",
        "Utilização à ARP - Órgão Participante": "Utilização à ARP - Órgão Participante",
        "Adesão à ARP de outro Órgão": "Adesão à ARP de outro Órgão",
        "Dispensa/Inexigibilidade": "Dispensa/Inexigibilidade"
    }

    dados_formulario["objeto_opcoes"] = gerar_opcoes_marcadas(dados_formulario["tipo_objeto"], opcoes_objeto)
    dados_formulario["forma_contratacao_opcoes"] = gerar_opcoes_marcadas(dados_formulario["forma_contratacao"], opcoes_forma)

    dados_formulario["estudo_tecnico_fixo"] = "(X) NÃO\n( ) SIM" # Este parece ser um campo fixo, se for para mudar, precisamos de mais informações.
    dados_formulario["plano_contratacao_fixo"] = "(X) SIM\n( ) NÃO" # Este também parece fixo.

    dados_formulario["data"] = datetime.now().strftime("Cuiabá-MT, %d de %B de %Y")
    
    # --- NOVOS DADOS PARA O TEMPLATE ---
    # Item 9: ARP SEPLAG (o placeholder no template é {{arp}})
    dados_formulario["arp"] = dados_formulario.get("arp_seplag", "Não informado ou Não se aplica.")

    # Item 11: Data Pretendida (o placeholder no template será {{data_pretendida}})
    # A data já vem formatada do app.py
    dados_formulario["data_pretendida"] = dados_formulario.get("data_pretendida", "Não informada.")

    # Item 13: Responsável pela Fiscalização (assumindo novos placeholders como {{fiscal_nome}} e {{fiscal_matricula}})
    dados_formulario["fiscal_nome"] = dados_formulario.get("fiscal_nome", "Não informado.")
    dados_formulario["fiscal_matricula"] = dados_formulario.get("fiscal_matricula", "Não informada.")
    # --- FIM DOS NOVOS DADOS ---


    dados_para_template = {
        **dados_formulario,
        "lista_itens": lista_itens
    }

    output_dir = "static/arquivos_gerados"
    os.makedirs(output_dir, exist_ok=True)

    # Usa o get com um fallback, caso lista_itens esteja vazia
    item_para_nome = "documento"
    if lista_itens and len(lista_itens) > 0:
        item_para_nome = lista_itens[0].get("descricao", "documento")

    nome_sanitizado = sanitize_filename(item_para_nome)

    nome_arquivo_base = f"DFD_{nome_sanitizado}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    nome_arquivo = os.path.join(output_dir, f"{nome_arquivo_base}.docx")

    doc.render(dados_para_template)
    doc.save(nome_arquivo)

    return nome_arquivo